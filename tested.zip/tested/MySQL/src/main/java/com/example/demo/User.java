package com.example.demo;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class User{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	private String name;
	
	private String email;
	
	public Integer getId() {
		return id;
	}
	 
	public void setId(Integer id) {
		this.id=id;
	}
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name=name;
	}
	public String getEmail() {
		return email;
	}
	public void setemail(String email) {
		this.email=email;
	}
	}